import java.util.*;

public class testPVA{

    public static Scanner sc;

    public static void main(String[] args) {
        
        napln();




    }


    public static void napln(){

        sc = new Scanner(System.in);

        System.out.println("napis cisla");

        String cisla = sc.nextLine();

        String splitC[] = cisla.split(",");

        for(int i= 0; i < splitC.length; i++){

                System.out.print(splitC[i]);

        }






        
            /** jsem uplne blbej :( */
        }


    }



